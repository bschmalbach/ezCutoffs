#' Calculate Fit Measure Cutoffs
#' @import ggplot2 lavaan moments pbapply
#' @description Calculate cutoff values for model fit measures used in structural equation modeling by simulating data sets with the same parameters (population model, number of observations).
#' @param model
#' \link[lavaan]{lavaan}-style Syntax of a user-specified model.
#' @param data A data frame containing the variables specified in model.
#' @param n_obs Specifies the number of observations. Only needed if no data frame is given. Can be given as a numeric vector representing the exact group sizes in multigroup analyses.
#' @param n_rep Number of replications.
#' @param which_fit Character vector, containing a selection of fit measures for which to calculate cutoff values. Only measures produced by \link[lavaan]{fitMeasures} can be chosen.
#' @param alpha_level Type I error rate.
#' @param normality Specify distributional assumptions for the simulated data: Either \code{"assumed"} for normal distribution, or \code{"empirical"} for distributions based on the skewness and kurtosis values of the empirical data.
#' @param missing_data Specify handling of missing values: Either \code{"complete"} to generate complete data sets, or \code{"missing"} to generate data with the same number of missing values on the observed variables as in the empirical data. \code{"missing"} should only be run using \code{"MLR"} estimation with \code{"missing = "FIML""}. Other arguments may lead to errors.
#' @param ...	 Additional arguments to pass to \link[lavaan]{lavaan}.
#' @details \code{model} is expected in standard lavaan nomenclature. The typical pre-multiplication mechanism is supported, with the exception of vectors (see Examples). Multigroup models should instead be specified using the \code{group} argument. \cr\cr
#' If \code{data} is not specified, the program will generate data based on the given \code{model} and \code{n_obs}. A numeric vector would signify multiple groups and \code{group} needs to be set to "group" in this case. Otherwise, \code{n_obs} is disregarded. \cr\cr
#' \code{missing_data = "missing"} assumes that the data is missing completely at random. That, is missings should not be distributed unevenly in multigroup models.\cr\cr
#' \code{...} allows the user to pass lavaan arguments to the model fitting procedure. Options include multigroup, repeated measures, growth curve, and multilevel models.
#'
#' @return An object of the class ezCutoffs, inspectable via \code{summary}, \code{plot}, and
#' \code{\link{compareFit}}
#'
#' @examples
#' ##model specification examples
#'
#' #simple uni-factorial model
#' model1 <- "F1 =~ a1 + a2 + a3 + a4 + a5"
#'
#' #path model
#' model2 <- "m ~ x1
#'            m ~ x2
#' 	   m ~ x3
#' 	   y ~ m"
#'
#' #two-factorial model with some exemplary pre-multiplications
#' model3 <- "F1 =~ NA*a1 + a2 + a3 + 0.8*a4 + a5
#'            F2 =~ b1 + start(0.8)*b2 + b3 + equal('F2 =~ b2')*b4 + b5
#'            F1 ~~ 0*F2"
#'
#'
#' ##function call
#' out <- ezCutoffs(model = model1, n_obs = 1000, n_rep = 100)
#'
#' \dontrun{
#' out <- ezCutoffs(model = model1, n_obs = c(300, 400), n_rep = 9999, which_fit = c("cfi.robust"),
#'estimator = "MLM", group = "group", group.equal = c("loadings", "intercepts"))
#' }
#'
#'
#'##retrieve output
#'summary(out)
#'plot(out)
#'
#'@seealso \code{\link{compareFit}}



#' @export
ezCutoffs <- function(model = NULL,
                      data = NULL,
                      n_obs = NULL,
                      n_rep = 1000,
                      which_fit = c("chisq", "cfi", "tli", "rmsea", "srmr"),
                      alpha_level = 0.05,
                      normality = "assumed",
                      missing_data = "complete",
                      ...) {

  #empirical fit-----------------------------------------------------------------


  #Occurences of c( in model
  if (grepl("\\c\\(", model) == T) {stop("Pre-multiplication with vectors is not supported.")}

  #Create data if none is given
  if (is.null(data)) {
    if (length(n_obs)==1) {
      data <- lavaan::simulateData(model, sample.nobs = n_obs)
    } else {
      simgroups <- sample(1:length(n_obs), size = sum(n_obs), replace = TRUE, prob = n_obs)
      data <- lavaan::simulateData(model, sample.nobs = n_obs)
      data[,(ncol(data)+1)] <- simgroups
      names(data)[ncol(data)] <- "group"
    }
  }

  fit <- lavaan::sem(model = model, data = data, ...)
  fit_measures <- lavaan::fitMeasures(fit)
  empirical_fit <- fit_measures


  #sanity check: which_fit in empirical fit?--------------------------------------
  length_di <- length(which_fit)
  for (i in 1:length_di) {
    name_warn <- which_fit[i]
    if (which_fit[i] %in% names(empirical_fit) == F)
      {stop(c("The following fit measure is not available with the given parameters: ", name_warn))}
  }

  #input parameters-------------------------------------------------------------
  pop_model <- lavaan::parTable(fit)
  n <- sum(lavaan::lavInspect(fit, what="nobs"))
  groups_var <- lavaan::lavInspect(fit, what="group")
  n_groups <- lavaan::lavInspect(fit, what="ngroups")
  group_labels <- lavaan::lavInspect(fit, what="group.label")
  #stop if grouping variable wiht only one level has been selected
  if ((length(groups_var)>0) & n_groups < 2) {stop("Less than 2 levels in the defined grouping variable.")}

  #generate random data----------------------------------------------------------

  cat("\nData Generation\n")

  if (normality == "empirical") { # With Skew/Kurt correction
    var_table <- lavaan::varTable(fit)
    var_table$skew<-moments::skewness(data[var_table$name])
    var_table$kurt<-moments::kurtosis(data[var_table$name])

    if (n_groups > 1) { #Multigroup
      group_sizes <- lavaan::lavInspect(fit, what="nobs")
      data_generation <- function() {
        lavaan::simulateData(pop_model, sample.nobs = group_sizes, group.label = group_labels, skewness = var_table$skew, kurtosis = var_table$kurt)
      }
      data_s_list <- vector("list", n_rep)
      data_s_list <- pbapply::pbreplicate(n_rep, data_generation(), simplify = F)

      for (i in 1:n_rep) {
        old_names <- names(data_s_list[[i]])
        new_names <- gsub("group", get("groups_var"), old_names)
        names(data_s_list[[i]]) <- new_names
      }

    } else {
      data_generation <- function() { #Singlegroup
        lavaan::simulateData(pop_model, sample.nobs = n, skewness = var_table$skew, kurtosis = var_table$kurt)
      }
      data_s_list <- vector("list", n_rep)
      data_s_list <- pbapply::pbreplicate(n_rep, data_generation(), simplify = F)
    }
  } else { # Without Skew/Kurt Correction

    if (n_groups > 1) { #Multigroup
      group_sizes <- lavaan::lavInspect(fit, what="nobs")
      data_generation <- function() {
        lavaan::simulateData(pop_model, sample.nobs = group_sizes, group.label = group_labels)
      }
      data_s_list <- vector("list", n_rep)
      data_s_list <- pbapply::pbreplicate(n_rep, data_generation(), simplify = F)

      for (i in 1:n_rep) {
        old_names <- names(data_s_list[[i]])
        new_names <- gsub("group", get("groups_var"), old_names)
        names(data_s_list[[i]]) <- new_names
      }

    } else { #Singlegroup
      data_generation <- function() {
        lavaan::simulateData(pop_model, sample.nobs = n)
      }
      data_s_list <- vector("list", n_rep)
      data_s_list <- pbapply::pbreplicate(n_rep, data_generation(), simplify = F)
    }
  }

  #add missings if requested

  if (missing_data == "missing") {
    misses <- list()
    var_table <- lavaan::varTable(fit)

    if (n_groups > 1) {
      for(i in 1:n_rep){
        for (v in 1:nrow(var_table)) {
          n_comp <- var_table[v,"nobs"]
          n_miss <- (sum(group_sizes) - n_comp)
          d_comp <- rep(0, times = n_comp)
          d_miss <- rep(1, times = n_miss)
          d_both <- sample(c(d_comp, d_miss), size = sum(group_sizes), replace = FALSE)
          v_miss <- match(1, d_both)
          data_s_list[[i]][v_miss,v] <- NA
        }
      }
    } else {
      for(i in 1:n_rep){
        for (v in 1:nrow(var_table)) {
          n_comp <- var_table[v,"nobs"]
          n_miss <- (n - n_comp)
          d_comp <- rep(0, times = n_comp)
          d_miss <- rep(1, times = n_miss)
          d_both <- sample(c(d_comp, d_miss), size = n, replace = FALSE)
          v_miss <- match(1, d_both)
          data_s_list[[i]][v_miss,v] <- NA
        }
      }
    }
  }

  #fit data in lavaan for fitmeasures()----------------------------------------------
  cat("\nModel Fitting\n")

  pb <- pbapply::timerProgressBar(max = n_rep, char = "+", width = 50)

  fit_s_list <- vector("list", length = n_rep)
  for (i in 1:n_rep) {
    fit_s <- lavaan::sem(model = model, data = data_s_list[[i]], ...)
    fit_s_list[[i]]<-fit_s
    pbapply::setTimerProgressBar(pb, i)
  }

  pbapply::closepb(pb)

  #extract fit_measures-----------------------------------------------------------
  fit_measures_s_list <- list()
  for (i in 1:n_rep) {
    fit_measures_s <- lavaan::fitmeasures(fit_s_list[[i]], fit.measures = which_fit)
    fit_measures_s_list[[i]] <- fit_measures_s
  }


  #get fit distributions------------------------------------------------------------

  m_fit_measures <- matrix(NA,n_rep,length(fit_measures_s_list[[1]]))

  for (i in 1:n_rep) {
    m_fit_measures[i,] <- matrix(unlist(fit_measures_s_list[[i]]), ncol = length(fit_measures_s_list[[i]]))
  }

  fit_distributions <- as.data.frame(m_fit_measures)
  ncols <- length(fit_measures_s_list[[1]])
  names(fit_distributions)[1:length(fit_measures_s_list[[1]])] <- names(fit_measures_s_list[[1]])

  #calculate descriptives----------------------------------------------------
  fit_simresults <- data.frame(matrix(NA,length_di,5))
  percentage_a <- 100*alpha_level
  cutoff_name <- paste(percentage_a, "% Cutoff", collapse = "", sep = "")
  names(fit_simresults) <- c("Empirical fit", "Simulation Mean", "Simulation SD", "Simulation Median", cutoff_name)
  rownames(fit_simresults) <- which_fit

  high_cut_index <- c("chisq", "chisq.scaled", "fmin", "aic", "bic", "bic2", "rmsea", "rmsea.scaled", "rmsea.ci.upper.scaled", "rmsea.robust",
                      "rmsea.ci.upper.robust", "rmsea.ci.upper", "rmr", "rmr_nomean", "srmr", "srmr_bentler", "srmr_bentler_nomean", "crmr",
                      "crmr_nomean", "srmr_mplus", "srmr_mplus_nomean", "ecvi")

  low_cut_index <- c("pvalue", "pvalue.scaled", "cfi", "tli", "nnfi", "rfi", "nfi", "pnfi", "ifi", "rni", "cfi.scaled", "tli.scaled", "cfi.robust", "tli.robust",
                     "nnfi.scaled", "nnfi.robust", "rfi.scaled", "nfi.scaled", "ifi.scaled", "rni.scaled", "rni.robust", "logl", "unrestricted.logl", "gfi",
                     "agfi", "pgfi", "mfi", "rmsea.pvalue", "rmsea.pvalue.scaled", "rmsea.pvalue.robust", "cn_05", "cn_01")


  for (i in 1:length_di) {
    if ((which_fit[i] %in% high_cut_index)==T) {
      fit_simresults[i,1] <- empirical_fit[which_fit[i]]
      fit_simresults[i,2] <- mean(fit_distributions[,i], na.rm = T)
      fit_simresults[i,3] <- stats::sd(fit_distributions[,i], na.rm = T)
      fit_simresults[i,4] <- stats::median(fit_distributions[,i], na.rm = T)
      fit_simresults[i,5] <- stats::quantile(fit_distributions[,i], probs=(1-alpha_level), na.rm = T)
    } else if ((which_fit[i] %in% low_cut_index)==T) {
      fit_simresults[i,1] <- empirical_fit[which_fit[i]]
      fit_simresults[i,2] <- mean(fit_distributions[,i], na.rm = T)
      fit_simresults[i,3] <- stats::sd(fit_distributions[,i], na.rm = T)
      fit_simresults[i,4] <- stats::median(fit_distributions[,i], na.rm = T)
      fit_simresults[i,5] <- stats::quantile(fit_distributions[,i], probs=alpha_level, na.rm = T)
    } else {
      fit_simresults[i,1] <- empirical_fit[which_fit[i]]
      fit_simresults[i,2] <- mean(fit_distributions[,i], na.rm = T)
      fit_simresults[i,3] <- stats::sd(fit_distributions[,i], na.rm = T)
      fit_simresults[i,4] <- stats::median(fit_distributions[,i], na.rm = T)
      fit_simresults[i,5] <- NA
    }
  }

  #simulation stats----------------------------------------------------------

  n_conv <- sum(!is.na(fit_distributions[,1]))
  s_est <- lavaan::lavInspect(fit, what="call")$estimator
  if (length(s_est)==0) {s_est <- lavaan::lavInspect(fit, what="options")$estimator}
  simulation_stats <- data.frame(matrix(c(n_rep, n_conv, s_est, alpha_level, n),1,5))
  names(simulation_stats)<-c("# Runs", "# Converged Runs", "Estimator", "Alpha Level", "Total Observations in Simulation")
  rownames(simulation_stats) <- ""

  #generate output---------------------------------------------------------------
  ezCutoffs_out <- list("simulation parameters"=simulation_stats, "data"=data_s_list, "fit distributions"=fit_distributions, "summary"=fit_simresults)
  class(ezCutoffs_out) <- "ezCutoffs"

  return(ezCutoffs_out)
}


#summary----------------------------------------------------------------------

#'@rawNamespace S3method(summary,ezCutoffs)

summary.ezCutoffs <- function(object, ...) {
  print(object[["simulation parameters"]])
  cat("\n")
  print(object[["summary"]])
}


#plot---------------------------------------------------------------

if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("count"))
}

#'@export
plot.ezCutoffs <- function(x, ...) {
  for (i in 1:nrow(x[["summary"]])){
    hist_plots <- ggplot2::ggplot(x[["fit distributions"]], ggplot2::aes_string(x=rownames(x[["summary"]])[i]))+
      ggplot2::geom_histogram(ggplot2::aes(y=stat(count)),color="black", fill="white", bins = 30)

    bar_height <- max(ggplot2::ggplot_build(hist_plots)$data[[1]]$count)

    hist_plots <- hist_plots + ggplot2::geom_vline(xintercept=x[["summary"]][i,1], color="blue", alpha=0.8)+
      ggplot2::annotate("text", x=x[["summary"]][i,1], y = bar_height, angle=0, label="Empirical")+
      ggplot2::geom_vline(xintercept=x[["summary"]][i,5], color="red",alpha=0.8)+
      ggplot2::annotate("text", x=x[["summary"]][i,5], y = bar_height, angle=0, label="Cutoff")+
      ggplot2::labs(title="Simulated Fit Distribution", y = "count")+
      ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5))
    (print(hist_plots))
  }
}
